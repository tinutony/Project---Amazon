﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumCsharpNUnitDemo.Amazon.Pages
{
    internal class CheckoutPage
    {
    }
}
